<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;

/**
 * 主题后台必须引入的组件
 */

require_once("libs/Settings.php");
require_once("libs/I18n.php");
require_once("libs/Lang.php");
require_once("libs/Content.php");
require_once("libs/Utils.php");
require_once("libs/CDN.php");
require_once("libs/Handsome.php");
require_once("libs/Preference.php");

require_once("libs/component/UA.php");
require_once("libs/component/Device.php");
require_once("functions_mine.php");



/*表单组件*/
require_once("libs/admin/FormElements.php");
require_once('libs/admin/Checkbox.php');
require_once('libs/admin/Text.php');
require_once('libs/admin/Radio.php');
require_once('libs/admin/Select.php');
require_once('libs/admin/Textarea.php');



